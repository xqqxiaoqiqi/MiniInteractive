﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NormalTool : MonoBehaviour
{
    private void Awake()
    {
       //拖动
    }
    private void ToolOnClick()
    {

    }

}
